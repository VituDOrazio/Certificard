function tema() {
  document.body.classList.toggle("dark");
}
